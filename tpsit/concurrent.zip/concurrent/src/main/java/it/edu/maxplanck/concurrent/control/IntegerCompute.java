package it.edu.maxplanck.concurrent.control;

import java.util.concurrent.Semaphore;

import it.edu.maxplanck.concurrent.model.IntegerQueue;

public class IntegerCompute implements Runnable{
	private IntegerQueue queue;
	private Semaphore sem;
	
	public IntegerCompute(IntegerQueue queue, Semaphore sem) {
		this.queue=queue;
		this.sem=sem;
	}
	
	public void run() {
		while (true) {
			try {
				sem.acquire();
				Integer i = queue.pop();
				
				//elaborazione intero
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
