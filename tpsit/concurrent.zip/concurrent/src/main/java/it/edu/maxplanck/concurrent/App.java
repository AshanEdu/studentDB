package it.edu.maxplanck.concurrent;

import java.util.concurrent.Semaphore;
import java.util.concurrent.ThreadLocalRandom;

import it.edu.maxplanck.concurrent.control.IntegerCompute;
import it.edu.maxplanck.concurrent.model.IntegerQueue;

public class App {
    public static void main( String[] args ){
		IntegerQueue queue = new IntegerQueue();
		Semaphore sem = new Semaphore(0);
		
		IntegerCompute compute = new IntegerCompute(queue, sem);
		
		Thread t1 = new Thread(compute);
		t1.setName("Thread1");
		Thread t2 = new Thread(compute);
		t1.setName("Thread2");
		
		t1.start();
		t2.start();
		
		while (true) {
			int i = ThreadLocalRandom.current().nextInt(0, 100);
			try {
				queue.push(Integer.valueOf(i));
				Thread.sleep(500);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
    }
}
